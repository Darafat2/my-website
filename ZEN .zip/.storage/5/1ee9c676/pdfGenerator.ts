import jsPDF from 'jspdf';

interface FormData {
  name: string;
  number: string;
  email: string;
  course: string;
  session: string;
}

const courseDetails = {
  'JFT': {
    fullName: 'Japan Foundation Test (JFT)',
    price: 15000,
    duration: '6 months'
  },
  'N4': {
    fullName: 'JLPT N4 - Japanese Language Proficiency Test',
    price: 18000,
    duration: '8 months'
  },
  'N5': {
    fullName: 'JLPT N5 - Japanese Language Proficiency Test',
    price: 12000,
    duration: '4 months'
  }
};

export const generateInvoicePDF = async (formData: FormData): Promise<Blob> => {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.width;
  const pageHeight = pdf.internal.pageSize.height;
  
  // Colors
  const primaryColor = [67, 56, 202]; // Indigo
  const textColor = [31, 41, 55]; // Gray-800
  const lightGray = [243, 244, 246]; // Gray-100
  
  // Header Background
  pdf.setFillColor(...primaryColor);
  pdf.rect(0, 0, pageWidth, 40, 'F');
  
  // Company Logo/Name
  pdf.setTextColor(255, 255, 255);
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(20);
  pdf.text('ZEN JAPANESE EDUCATION CONSULTANCY', pageWidth / 2, 15, { align: 'center' });
  
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Professional Japanese Language Training', pageWidth / 2, 25, { align: 'center' });
  pdf.text('Invoice', pageWidth / 2, 35, { align: 'center' });
  
  // Reset text color for body
  pdf.setTextColor(...textColor);
  
  // Invoice Details
  const invoiceNumber = `INV-${Date.now()}`;
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  let yPos = 55;
  
  // Invoice Info Section
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Invoice Number:', 15, yPos);
  pdf.setFont('helvetica', 'normal');
  pdf.text(invoiceNumber, 60, yPos);
  
  yPos += 8;
  pdf.setFont('helvetica', 'bold');
  pdf.text('Date:', 15, yPos);
  pdf.setFont('helvetica', 'normal');
  pdf.text(currentDate, 60, yPos);
  
  yPos += 20;
  
  // Student Information Section
  pdf.setFillColor(...lightGray);
  pdf.rect(15, yPos - 5, pageWidth - 30, 25, 'F');
  
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('STUDENT INFORMATION', 20, yPos + 5);
  
  yPos += 15;
  pdf.setFontSize(11);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Name:', 20, yPos);
  pdf.setFont('helvetica', 'normal');
  pdf.text(formData.name, 50, yPos);
  
  yPos += 8;
  pdf.setFont('helvetica', 'bold');
  pdf.text('Phone:', 20, yPos);
  pdf.setFont('helvetica', 'normal');
  pdf.text(formData.number, 50, yPos);
  
  yPos += 8;
  pdf.setFont('helvetica', 'bold');
  pdf.text('Email:', 20, yPos);
  pdf.setFont('helvetica', 'normal');
  pdf.text(formData.email, 50, yPos);
  
  yPos += 20;
  
  // Course Information Section
  const courseInfo = courseDetails[formData.course as keyof typeof courseDetails];
  
  pdf.setFillColor(...lightGray);
  pdf.rect(15, yPos - 5, pageWidth - 30, 35, 'F');
  
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('COURSE DETAILS', 20, yPos + 5);
  
  yPos += 15;
  pdf.setFontSize(11);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Course:', 20, yPos);
  pdf.setFont('helvetica', 'normal');
  pdf.text(courseInfo.fullName, 50, yPos);
  
  yPos += 8;
  pdf.setFont('helvetica', 'bold');
  pdf.text('Session:', 20, yPos);
  pdf.setFont('helvetica', 'normal');
  pdf.text(formData.session, 50, yPos);
  
  yPos += 8;
  pdf.setFont('helvetica', 'bold');
  pdf.text('Duration:', 20, yPos);
  pdf.setFont('helvetica', 'normal');
  pdf.text(courseInfo.duration, 50, yPos);
  
  yPos += 20;
  
  // Billing Section
  pdf.setFillColor(...primaryColor);
  pdf.rect(15, yPos - 5, pageWidth - 30, 10, 'F');
  
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('BILLING SUMMARY', 20, yPos + 2);
  
  pdf.setTextColor(...textColor);
  yPos += 15;
  
  // Billing table header
  pdf.setFillColor(248, 250, 252);
  pdf.rect(15, yPos - 3, pageWidth - 30, 10, 'F');
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Description', 20, yPos + 3);
  pdf.text('Amount', pageWidth - 40, yPos + 3, { align: 'right' });
  
  yPos += 15;
  
  // Course fee
  pdf.setFont('helvetica', 'normal');
  pdf.text(courseInfo.fullName, 20, yPos);
  pdf.text(`₹${courseInfo.price.toLocaleString()}`, pageWidth - 40, yPos, { align: 'right' });
  
  yPos += 10;
  
  // Total line
  pdf.setDrawColor(...primaryColor);
  pdf.setLineWidth(1);
  pdf.line(15, yPos, pageWidth - 15, yPos);
  
  yPos += 10;
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(12);
  pdf.text('TOTAL AMOUNT:', pageWidth - 80, yPos, { align: 'right' });
  pdf.text(`₹${courseInfo.price.toLocaleString()}`, pageWidth - 40, yPos, { align: 'right' });
  
  yPos += 25;
  
  // Terms and Conditions
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Terms & Conditions:', 20, yPos);
  yPos += 8;
  
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);
  const terms = [
    '• Payment is due within 7 days of invoice date',
    '• Course fees are non-refundable after course commencement',
    '• Student must maintain 80% attendance to complete the course',
    '• Certificate will be issued upon successful completion of the course'
  ];
  
  terms.forEach(term => {
    pdf.text(term, 20, yPos);
    yPos += 6;
  });
  
  // Footer
  yPos = pageHeight - 30;
  pdf.setFillColor(...primaryColor);
  pdf.rect(0, yPos - 5, pageWidth, 25, 'F');
  
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Thank you for choosing ZEN Japanese Education Consultancy!', pageWidth / 2, yPos + 5, { align: 'center' });
  pdf.text('Contact: info@zenjapanese.com | Phone: +91-9876543210', pageWidth / 2, yPos + 12, { align: 'center' });
  
  return new Promise((resolve) => {
    const pdfBlob = pdf.output('blob');
    resolve(pdfBlob);
  });
};