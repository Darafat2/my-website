import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';
import { generateInvoicePDF } from '@/lib/pdfGenerator';
import { sendInvoiceEmail } from '@/lib/emailService';

interface FormData {
  name: string;
  number: string;
  email: string;
  course: string;
  session: string;
  paymentMethod: string;
}

export default function InvoiceForm() {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    number: '',
    email: '',
    course: '',
    session: '',
    paymentMethod: 'cash'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.name || !formData.number || !formData.email || !formData.course || !formData.session || !formData.paymentMethod) {
      toast.error('Please fill in all fields');
      return;
    }

    setIsSubmitting(true);

    try {
      // Generate PDF
      const pdfBlob = await generateInvoicePDF(formData);
      
      // Send email
      await sendInvoiceEmail(formData, pdfBlob);
      
      // Download PDF for user
      const url = URL.createObjectURL(pdfBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Invoice_${formData.name}_${Date.now()}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success('Invoice generated and sent successfully!');
      
      // Reset form
      setFormData({
        name: '',
        number: '',
        email: '',
        course: '',
        session: '',
        paymentMethod: 'cash'
      });
    } catch (error) {
      console.error('Error generating invoice:', error);
      toast.error('Failed to generate invoice. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mb-6">
            <img 
              src="/assets/zen-logo.jpg" 
              alt="ZEN Japanese Education Consultancy Logo" 
              className="mx-auto h-32 w-auto object-contain rounded-lg shadow-lg"
            />
          </div>
          <h1 className="text-4xl font-bold text-red-700 mb-2">
            ZEN JAPANESE EDUCATION CONSULTANCY
          </h1>
          <p className="text-lg text-gray-600">Invoice Generation Portal</p>
        </div>

        {/* Invoice Form */}
        <Card className="shadow-xl">
          <CardHeader className="bg-red-600 text-white rounded-t-lg">
            <CardTitle className="text-2xl text-center">Create Invoice</CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name Field */}
              <div className="space-y-2">
                <Label htmlFor="name" className="text-sm font-medium text-gray-700">
                  Full Name *
                </Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Enter your full name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="w-full"
                />
              </div>

              {/* Phone Number Field */}
              <div className="space-y-2">
                <Label htmlFor="number" className="text-sm font-medium text-gray-700">
                  Phone Number *
                </Label>
                <Input
                  id="number"
                  type="tel"
                  placeholder="Enter your phone number"
                  value={formData.number}
                  onChange={(e) => handleInputChange('number', e.target.value)}
                  className="w-full"
                />
              </div>

              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                  Email Address *
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email address"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full"
                />
              </div>

              {/* Course Selection */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">
                  Course *
                </Label>
                <Select value={formData.course} onValueChange={(value) => handleInputChange('course', value)}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select a course" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="JFT">JFT (Japan Foundation Test)</SelectItem>
                    <SelectItem value="N4">JLPT N4 (Japanese Language Proficiency Test)</SelectItem>
                    <SelectItem value="N5">JLPT N5 (Japanese Language Proficiency Test)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Session Field */}
              <div className="space-y-2">
                <Label htmlFor="session" className="text-sm font-medium text-gray-700">
                  Session *
                </Label>
                <Input
                  id="session"
                  type="text"
                  placeholder="Enter session details (e.g., Morning Batch, Evening Batch)"
                  value={formData.session}
                  onChange={(e) => handleInputChange('session', e.target.value)}
                  className="w-full"
                />
              </div>

              {/* Payment Method */}
              <div className="space-y-3">
                <Label className="text-sm font-medium text-gray-700">
                  Payment Method *
                </Label>
                <RadioGroup 
                  value={formData.paymentMethod} 
                  onValueChange={(value) => handleInputChange('paymentMethod', value)}
                  className="flex flex-col space-y-2"
                >
                  <div className="flex items-center space-x-2 p-3 border rounded-lg bg-green-50 border-green-200">
                    <RadioGroupItem value="cash" id="cash" />
                    <Label htmlFor="cash" className="text-green-700 font-medium cursor-pointer flex-1">
                      💵 Cash Payment (Pay at Center)
                    </Label>
                  </div>
                </RadioGroup>
                <p className="text-sm text-gray-500 mt-2">
                  Payment can be made in cash at our center upon course enrollment.
                </p>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 text-lg"
              >
                {isSubmitting ? 'Generating Invoice...' : 'Generate Invoice'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 text-gray-500">
          <p>© 2024 ZEN JAPANESE EDUCATION CONSULTANCY. All rights reserved.</p>
          <div className="mt-2 space-y-1">
            <p>Email: zenjapanessc@gmail.com</p>
            <p>Phone: +8801332117220, +8801905000511</p>
          </div>
        </div>
      </div>
    </div>
  );
}