interface FormData {
  name: string;
  number: string;
  email: string;
  course: string;
  session: string;
  paymentMethod: string;
}

export const sendInvoiceEmail = async (formData: FormData, pdfBlob: Blob): Promise<void> => {
  // Convert PDF blob to base64
  const base64PDF = await blobToBase64(pdfBlob);
  
  const emailData = {
    to: formData.email,
    subject: `Invoice for ${formData.course} Course - ZEN Japanese Education Consultancy`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8fafc;">
        <div style="background-color: #c41e3a; padding: 20px; text-align: center; color: white; border-radius: 8px 8px 0 0;">
          <h1 style="margin: 0; font-size: 24px;">ZEN JAPANESE EDUCATION CONSULTANCY</h1>
          <p style="margin: 5px 0 0 0; font-size: 14px;">Professional Japanese Language Training</p>
        </div>
        
        <div style="background-color: white; padding: 30px; border-radius: 0 0 8px 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
          <h2 style="color: #1f2937; margin-bottom: 20px;">Dear ${formData.name},</h2>
          
          <p style="color: #4b5563; line-height: 1.6; margin-bottom: 20px;">
            Thank you for enrolling in our <strong>${formData.course}</strong> course. Please find your invoice attached to this email.
          </p>
          
          <div style="background-color: #f3f4f6; padding: 20px; border-radius: 6px; margin: 20px 0;">
            <h3 style="color: #374151; margin-top: 0;">Course Details:</h3>
            <ul style="color: #4b5563; margin: 10px 0;">
              <li><strong>Course:</strong> ${formData.course}</li>
              <li><strong>Session:</strong> ${formData.session}</li>
              <li><strong>Student Name:</strong> ${formData.name}</li>
              <li><strong>Phone:</strong> ${formData.number}</li>
              <li><strong>Payment Method:</strong> ${formData.paymentMethod === 'cash' ? 'Cash Payment at Center' : formData.paymentMethod}</li>
            </ul>
          </div>
          
          <p style="color: #4b5563; line-height: 1.6; margin-bottom: 20px;">
            If you have any questions or need assistance, please don't hesitate to contact us.
          </p>
          
          <p style="color: #4b5563; line-height: 1.6;">
            Best regards,<br>
            <strong>ZEN Japanese Education Consultancy Team</strong>
          </p>
          
          <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 30px 0;">
          
          <div style="text-align: center; color: #6b7280; font-size: 12px;">
            <p>Contact us: info@zenjapanese.com | +91-9876543210</p>
            <p>Visit our website for more information about our courses</p>
          </div>
        </div>
      </div>
    `,
    attachments: [
      {
        filename: `Invoice_${formData.name}_${Date.now()}.pdf`,
        content: base64PDF.split(',')[1], // Remove data:application/pdf;base64, prefix
        contentType: 'application/pdf'
      }
    ]
  };

  try {
    // In a real application, you would send this to your backend API
    // For now, we'll simulate the email sending
    console.log('Email data prepared:', emailData);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // In production, replace this with actual email service call:
    // const response = await fetch('/api/send-email', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(emailData)
    // });
    
    console.log('Email sent successfully to:', formData.email);
  } catch (error) {
    console.error('Error sending email:', error);
    throw new Error('Failed to send email');
  }
};

const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};